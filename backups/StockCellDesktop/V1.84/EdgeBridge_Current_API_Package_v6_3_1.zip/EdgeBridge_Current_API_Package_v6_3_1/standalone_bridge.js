'use strict';

const { createEmbeddedEdgeBridge } = require('./edge_bridge_server');

const port = Number(process.env.EDGE_BRIDGE_PORT || 17890);
const host = process.env.EDGE_BRIDGE_HOST || '127.0.0.1';

const bridge = createEmbeddedEdgeBridge({ host, port });

async function main() {
  try {
    const status = await bridge.start();
    console.log('======================================================');
    console.log(' EdgeBridge started');
    console.log(` URL: http://${host}:${status.port || port}`);
    console.log(' Keep this window open while the Edge extension works.');
    console.log(' Health: GET /api/health');
    console.log(' Token : GET /api/watchlist');
    console.log('======================================================');
  } catch (error) {
    console.error('EdgeBridge failed to start:', error && error.stack || error);
    if (error && error.code === 'EADDRINUSE') {
      console.error(`Port ${port} is already in use. Close the other bridge/app or choose another port.`);
    }
    process.exitCode = 1;
  }
}

async function shutdown(signal) {
  console.log(`\n${signal}: stopping EdgeBridge...`);
  try { await bridge.stop(); } catch (_) {}
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

main();
