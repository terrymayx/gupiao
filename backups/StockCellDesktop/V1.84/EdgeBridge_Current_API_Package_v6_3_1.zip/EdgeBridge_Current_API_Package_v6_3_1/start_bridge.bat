@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Starting current EdgeBridge on 127.0.0.1:17890 ...
node standalone_bridge.js
pause
