const http = require('http');
const crypto = require('crypto');

function createEmbeddedEdgeBridge(options = {}) {
  const host = options.host || '127.0.0.1';
  const port = Number(options.port ?? 17890);
  const token = crypto.randomBytes(24).toString('hex');
  const startedAt = Date.now();

  // 连接第一阶段：给 Edge 扩展一个可用自选股列表，方便“立即获取一次”直接产生 browser-data。
  let watchlist = Array.isArray(options.watchlist) && options.watchlist.length
    ? options.watchlist
    : [
        {key:'A股:688981', symbol:'sh688981'},
        {key:'A股:688256', symbol:'sh688256'},
        {key:'A股:300059', symbol:'sz300059'},
        {key:'A股:600519', symbol:'sh600519'},
        {key:'A股:002475', symbol:'sz002475'}
      ];

  const state = {
    listening: false,
    listenError: null,
    requestCount: 0,
    lastRequestAt: 0,
    lastExtensionAt: 0,
    lastExtensionPath: '',
    lastBrowserDataAt: 0,
    lastBrowserData: null,
    sectorSnapshot: [],
    sectorSnapshotAt: 0,
    sectorParseDebug: {visited:0,candidates:0,paths:[]},
    errors: [],
    cache: new Map(),
    queues: {
      industry: new Map(),
      peer: new Map(),
      event: new Map()
    }
  };

  function iso(ms) {
    return ms ? new Date(ms).toISOString() : null;
  }

  function json(res, status, data, extraHeaders = {}) {
    const body = Buffer.from(JSON.stringify(data), 'utf8');
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': body.length,
      'Cache-Control': 'no-store, no-cache, must-revalidate',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-StockTray-Token',
      'Access-Control-Max-Age': '600',
      ...extraHeaders
    });
    res.end(body);
  }

  function extensionLike(req) {
    const origin = String(req.headers.origin || '');
    const ua = String(req.headers['user-agent'] || '');
    return origin.startsWith('chrome-extension://') ||
           origin.startsWith('edge-extension://') ||
           /Edg\//i.test(ua);
  }

  function markRequest(req, pathname) {
    const now = Date.now();
    state.requestCount += 1;
    state.lastRequestAt = now;

    // 内部接口命中，或者请求来自 Edge/扩展，就视为扩展活动。
    if (
      extensionLike(req) ||
      pathname === '/api/browser-data' ||
      /\/api\/(industry|peer|event)-(requests|data|wakeup)/.test(pathname)
    ) {
      state.lastExtensionAt = now;
      state.lastExtensionPath = pathname;
    }
  }

  function extractToken(req, url, body) {
    return String(
      req.headers['x-stocktray-token'] ||
      body?.token ||
      url.searchParams.get('token') ||
      ''
    );
  }

  function authOk(req, url, body, internal = false) {
    const supplied = extractToken(req, url, body);
    if (supplied === token) return true;

    // 兼容扩展内部调用：若没有显式错误 Token 且来源是 chrome-extension，可放行。
    // 这样旧扩展即使某个内部 fetch 没带 Token，也能先完成“已连接”阶段。
    if (internal && !supplied && extensionLike(req)) return true;
    return false;
  }

  function requestBody(req, maxBytes = 2 * 1024 * 1024) {
    return new Promise((resolve, reject) => {
      const chunks = [];
      let total = 0;
      req.on('data', chunk => {
        total += chunk.length;
        if (total > maxBytes) {
          reject(Object.assign(new Error('request body too large'), {statusCode: 413}));
          req.destroy();
          return;
        }
        chunks.push(chunk);
      });
      req.on('end', () => {
        if (!chunks.length) return resolve({});
        const raw = Buffer.concat(chunks).toString('utf8');
        try {
          resolve(JSON.parse(raw));
        } catch {
          reject(Object.assign(new Error('invalid json'), {statusCode: 400}));
        }
      });
      req.on('error', reject);
    });
  }

  function statusPayload() {
    const now = Date.now();
    const cacheAge = {};
    for (const [key, item] of state.cache.entries()) {
      cacheAge[key] = Math.max(0, (now - item.updatedAt) / 1000);
    }

    return {
      ok: true,
      running: state.listening,
      provider: 'edge_tencent',
      embedded: true,
      bridge_owner: 'stock_galaxy',
      port: server.address()?.port || port,
      edge_extension_connected: !!state.lastExtensionAt && (now - state.lastExtensionAt) < 30000,
      last_extension_at: iso(state.lastExtensionAt),
      last_extension_path: state.lastExtensionPath || null,
      last_browser_data_at: iso(state.lastBrowserDataAt),
      request_count: state.requestCount,
      peer_queue: {
        queued: [...state.queues.peer.values()].filter(x=>x.status==='queued').length,
        processing: [...state.queues.peer.values()].filter(x=>x.status==='processing').length,
        success: [...state.queues.peer.values()].filter(x=>x.status==='success').length,
        failed: [...state.queues.peer.values()].filter(x=>x.status==='failed').length
      },
      cache_age: cacheAge,
      errors: state.errors.slice(-20)
    };
  }

  function newId(prefix) {
    return `${prefix}_${Date.now()}_${crypto.randomBytes(5).toString('hex')}`;
  }

  function createTask(kind, body) {
    const id = String(body.request_id || newId(kind));
    const task = {
      ...body,
      request_id: id,
      status: 'queued',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      claimed_at: null,
      result: null,
      error: null
    };
    state.queues[kind].set(id, task);
    return task;
  }

  function publicTask(task, resultKey) {
    if (!task) return null;
    const publicStatus =
      task.status === 'queued' || task.status === 'processing'
        ? 'pending'
        : task.status;

    const base = {
      ok: true,
      request_id: task.request_id,
      status: publicStatus,
      internal_status: task.status,
      source: task.result?.source ?? null,
      error: task.error ?? task.result?.error ?? null,
      debug: task.result?.debug ?? null,
      updated_at: task.updated_at
    };

    if (task.symbol != null) base.symbol = task.symbol;
    if (task.kind != null) base.kind = task.kind;

    if (resultKey === 'rows') base.rows = task.result?.rows ?? [];
    if (resultKey === 'stocks') {
      base.symbols = task.result?.symbols ?? [];
      base.stocks = task.result?.stocks ?? [];
    }
    return base;
  }

  function pendingTasks(kind, limit) {
    const now = Date.now();
    const items = [...state.queues[kind].values()]
      .filter(t => {
        if (t.status === 'queued') return true;
        if (t.status === 'pending') return true; // 兼容旧状态
        if (t.status === 'processing' && t.claimed_at && now - t.claimed_at > 45000) return true;
        return false;
      })
      .slice(0, Math.max(1, Math.min(20, Number(limit) || 5)));

    for (const t of items) {
      t.status = 'processing';
      t.claimed_at = now;
      t.updated_at = new Date().toISOString();
    }

    return items.map(t => {
      const x = {...t};
      delete x.result;
      return x;
    });
  }

  function applyTaskResult(kind, body) {
    const id = String(body.request_id || '');
    if (!id) return {ok:false, status:400, error:'missing request_id'};
    const task = state.queues[kind].get(id);
    if (!task) return {ok:false, status:404, error:'request_id not found'};

    const incomingStatus = String(body.status || '').toLowerCase();
    task.status = incomingStatus === 'failed' || body.error ? 'failed' : 'success';
    task.error = body.error || null;
    task.updated_at = new Date().toISOString();
    task.result = {...body};
    return {ok:true, status:200, task};
  }


  function firstDefined(obj, keys) {
    for (const k of keys) {
      if (obj && obj[k] != null && obj[k] !== '') return {key:k, value:obj[k]};
    }
    return null;
  }

  function parseMoneyToYi(raw, fieldKey='') {
    if (raw == null || raw === '') return null;
    const key = String(fieldKey || '').toLowerCase();

    if (typeof raw === 'string') {
      let s = raw.trim().replace(/,/g,'').replace(/\s+/g,'');
      if (!s || s === '-' || s === '--') return null;
      let mul = null;
      if (s.includes('亿')) { mul = 1; s = s.replace(/亿元?|亿/g,''); }
      else if (s.includes('万')) { mul = 1/10000; s = s.replace(/万元?|万/g,''); }
      else if (s.includes('元')) { mul = 1/100000000; s = s.replace(/元/g,''); }
      const n = Number(s.replace('%',''));
      if (!Number.isFinite(n)) return null;
      if (mul != null) return n * mul;
      raw = n;
    }

    const n = Number(raw);
    if (!Number.isFinite(n)) return null;

    // 东方财富 f62 / f66 / f72 等资金字段单位是“元”。
    if (/^f(62|66|72|78|84)$/.test(key)) return n / 100000000;
    if (/(yuan|amount_raw|netinflowraw|net_flow_raw|main_net_raw)/.test(key)) return n / 100000000;
    if (/(yi|billion_cn|100m)/.test(key)) return n;

    // 通用 net_inflow 字段：大数按元处理，小数值视为已换算“亿”。
    return Math.abs(n) >= 100000 ? n / 100000000 : n;
  }

  function normalizeSectorCandidate(obj, contextName='', path='') {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return null;

    const codeHit = firstDefined(obj, ['code','symbol','sector_code','sectorCode','board_code','boardCode','plate_code','plateCode','f12','F12']);
    const code = codeHit ? String(codeHit.value) : '';

    const nameHit = firstDefined(obj, [
      'name','sector_name','sectorName','industry_name','industryName',
      'board_name','boardName','plate_name','plateName','f14','F14','NAME','BK_NAME','bk_name'
    ]);
    let name = nameHit ? String(nameHit.value).trim() : String(contextName || '').trim();

    const flowHit = firstDefined(obj, [
      'net_inflow','netInflow','net_flow','netFlow','main_net_inflow','mainNetInflow',
      'main_net_flow','mainNetFlow','main_flow','mainFlow','capital_flow','capitalFlow',
      'fund_flow','fundFlow','net_amount','netAmount','f62','F62'
    ]);
    if (!flowHit) return null;

    const sectorPath = /(sector|industry|board|plate|bk|板块|行业)/i.test(path);
    const sectorCode = /^BK\d{4}$/i.test(code);
    if (!sectorPath && !sectorCode) return null;

    if (!name || /^(items|list|data|rows|result|market|sectors?|industr(?:y|ies)|boards?|plates?)$/i.test(name)) {
      if (sectorCode) name = code.toUpperCase();
      else return null;
    }

    const flow = parseMoneyToYi(flowHit.value, flowHit.key);
    if (!Number.isFinite(flow)) return null;

    const pctHit = firstDefined(obj, ['change_percent','changePercent','pct','pct_change','pctChange','f3','F3']);
    const pct = pctHit ? Number(String(pctHit.value).replace('%','')) : null;

    return {
      name,
      code: sectorCode ? code.toUpperCase() : code,
      flow: Number(flow.toFixed(4)),
      pct: Number.isFinite(pct) ? pct : null,
      source_field: flowHit.key,
      source_path: path
    };
  }

  function extractSectorSnapshot(root) {
    const debug = {visited:0,candidates:0,paths:[]};
    const out = [];
    const seenObjects = new WeakSet();
    const stack = [{value:root, path:'browserData', contextName:''}];
    const maxVisited = 12000;

    while (stack.length && debug.visited < maxVisited) {
      const cur = stack.pop();
      const value = cur.value;
      if (!value || typeof value !== 'object') continue;
      if (seenObjects.has(value)) continue;
      seenObjects.add(value);
      debug.visited++;

      if (!Array.isArray(value)) {
        const candidate = normalizeSectorCandidate(value, cur.contextName, cur.path);
        if (candidate) {
          out.push(candidate);
          debug.candidates++;
          if (debug.paths.length < 20) debug.paths.push(candidate.source_path);
        }
      }

      if (Array.isArray(value)) {
        const max = Math.min(value.length, 5000);
        for (let i=0;i<max;i++) {
          const child = value[i];
          if (child && typeof child === 'object') {
            stack.push({value:child, path:`${cur.path}[${i}]`, contextName:''});
          }
        }
      } else {
        for (const [k, child] of Object.entries(value)) {
          if (!child || typeof child !== 'object') continue;
          const nextPath = `${cur.path}.${k}`;
          // 若对象 key 本身就是中文板块名，给子对象作为 fallback 名称。
          const fallbackName = /[\u4e00-\u9fff]/.test(k) ? k : '';
          stack.push({value:child, path:nextPath, contextName:fallbackName});
        }
      }
    }

    // 同名/同代码去重，保留绝对资金值更可信的一项。
    const map = new Map();
    for (const s of out) {
      const key = s.code || s.name;
      const prev = map.get(key);
      if (!prev || Math.abs(s.flow) > Math.abs(prev.flow)) map.set(key, s);
    }

    const sectors = [...map.values()]
      .filter(s => Number.isFinite(s.flow) && Math.abs(s.flow) > 0.000001)
      .sort((a,b) => Math.abs(b.flow) - Math.abs(a.flow));

    return {sectors, debug};
  }

  function updateBrowserCache(body) {
    state.lastBrowserDataAt = Date.now();
    state.lastBrowserData = body;

    const candidates = [
      ['browser-data', body],
      ['quotes', body?.quotes],
      ['quote', body?.quote],
      ['intraday', body?.intraday],
      ['sectors', body?.sectors],
      ['market', body?.market]
    ];
    for (const [key, value] of candidates) {
      if (value != null) state.cache.set(key, {value, updatedAt: Date.now()});
    }

    // V6.1：从扩展真实 browser-data 中自动提取板块净流入/净流出。
    const parsed = extractSectorSnapshot(body);
    state.sectorParseDebug = parsed.debug;
    if (parsed.sectors.length) {
      state.sectorSnapshot = parsed.sectors;
      state.sectorSnapshotAt = Date.now();
      state.cache.set('live-sector-flows', {
        value: parsed.sectors,
        updatedAt: state.sectorSnapshotAt
      });
    }
  }

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url || '/', `http://${host}:${port}`);
    const p = url.pathname;
    markRequest(req, p);

    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, X-StockTray-Token',
        'Access-Control-Max-Age': '600'
      });
      return res.end();
    }

    let body = {};
    if (req.method === 'POST') {
      try {
        body = await requestBody(req);
      } catch (err) {
        return json(res, err.statusCode || 400, {ok:false, error:err.message});
      }
    }

    // ----- 公共基础接口 -----
    if (req.method === 'GET' && p === '/api/health') {
      return json(res, 200, {
        ok: true,
        provider: 'edge_tencent',
        port: server.address()?.port || port,
        embedded: true,
        bridge_owner: 'stock_galaxy'
      });
    }

    if (req.method === 'GET' && p === '/api/watchlist') {
      return json(res, 200, {
        ok: true,
        token,
        stocks: watchlist
      });
    }

    if (req.method === 'GET' && p === '/api/status') {
      if (!authOk(req, url, body, false)) return json(res, 401, {ok:false, error:'unauthorized'});
      return json(res, 200, statusPayload());
    }

    // ----- 扩展内部实时回传 -----
    if (req.method === 'POST' && p === '/api/browser-data') {
      if (!authOk(req, url, body, true)) return json(res, 401, {ok:false, error:'unauthorized'});
      updateBrowserCache(body);
      return json(res, 200, {
        ok: true,
        accepted: true,
        received_at: new Date().toISOString()
      });
    }

    // ----- 普通消费项目的任务提交/查询 -----
    if (req.method === 'POST' && p === '/api/industry-request') {
      if (!authOk(req, url, body, false)) return json(res, 401, {ok:false, error:'unauthorized'});
      const task = createTask('industry', body);
      return json(res, 200, {
        ok:true, request_id:task.request_id, symbol:task.symbol,
        start:task.start, end:task.end,
        fixed_api:!!task.fixed_api, dynamic_api:!!task.dynamic_api,
        status:'queued', created_at:task.created_at
      });
    }

    if (req.method === 'GET' && p === '/api/industry-result') {
      if (!authOk(req, url, body, false)) return json(res, 401, {ok:false, error:'unauthorized'});
      const task = state.queues.industry.get(String(url.searchParams.get('request_id') || ''));
      if (!task) return json(res, 404, {ok:false, error:'request_id not found'});
      return json(res, 200, publicTask(task, 'rows'));
    }

    if (req.method === 'POST' && p === '/api/peer-request') {
      if (!authOk(req, url, body, false)) return json(res, 401, {ok:false, error:'unauthorized'});
      const task = createTask('peer', body);
      return json(res, 200, {
        ok:true, request_id:task.request_id, symbol:task.symbol,
        limit:Number(task.limit)||10, direction:task.direction||'inflow',
        status:'queued', created_at:task.created_at
      });
    }

    if (req.method === 'GET' && p === '/api/peer-result') {
      if (!authOk(req, url, body, false)) return json(res, 401, {ok:false, error:'unauthorized'});
      const task = state.queues.peer.get(String(url.searchParams.get('request_id') || ''));
      if (!task) return json(res, 404, {ok:false, error:'request_id not found'});
      return json(res, 200, publicTask(task, 'stocks'));
    }

    if (req.method === 'POST' && p === '/api/event-request') {
      if (!authOk(req, url, body, false)) return json(res, 401, {ok:false, error:'unauthorized'});
      const task = createTask('event', body);
      return json(res, 200, {
        ok:true, request_id:task.request_id, kind:task.kind, symbol:task.symbol,
        status:'queued', created_at:task.created_at
      });
    }

    if (req.method === 'GET' && p === '/api/event-result') {
      if (!authOk(req, url, body, false)) return json(res, 401, {ok:false, error:'unauthorized'});
      const task = state.queues.event.get(String(url.searchParams.get('request_id') || ''));
      if (!task) return json(res, 404, {ok:false, error:'request_id not found'});
      return json(res, 200, publicTask(task, 'rows'));
    }

    // ----- Edge 扩展领取任务 -----
    if (req.method === 'GET' && p === '/api/industry-requests') {
      if (!authOk(req, url, body, true)) return json(res, 401, {ok:false, error:'unauthorized'});
      const requests = pendingTasks('industry', url.searchParams.get('limit'));
      return json(res, 200, {ok:true, requests, tasks:requests, items:requests});
    }

    if (req.method === 'GET' && p === '/api/peer-requests') {
      if (!authOk(req, url, body, true)) return json(res, 401, {ok:false, error:'unauthorized'});
      const requests = pendingTasks('peer', url.searchParams.get('limit'));
      return json(res, 200, {ok:true, requests, tasks:requests, items:requests});
    }

    if (req.method === 'GET' && p === '/api/event-requests') {
      if (!authOk(req, url, body, true)) return json(res, 401, {ok:false, error:'unauthorized'});
      const requests = pendingTasks('event', url.searchParams.get('limit'));
      return json(res, 200, {ok:true, requests, tasks:requests, items:requests});
    }

    // ----- Edge 扩展回传任务结果 -----
    if (req.method === 'POST' && p === '/api/industry-data') {
      if (!authOk(req, url, body, true)) return json(res, 401, {ok:false, error:'unauthorized'});
      const applied = applyTaskResult('industry', body);
      return json(res, applied.status, applied.ok
        ? {ok:true, request_id:applied.task.request_id, status:applied.task.status}
        : {ok:false, error:applied.error});
    }

    if (req.method === 'POST' && p === '/api/peer-data') {
      if (!authOk(req, url, body, true)) return json(res, 401, {ok:false, error:'unauthorized'});
      const applied = applyTaskResult('peer', body);
      return json(res, applied.status, applied.ok
        ? {ok:true, request_id:applied.task.request_id, status:applied.task.status}
        : {ok:false, error:applied.error});
    }

    if (req.method === 'POST' && p === '/api/event-data') {
      if (!authOk(req, url, body, true)) return json(res, 401, {ok:false, error:'unauthorized'});
      const applied = applyTaskResult('event', body);
      return json(res, applied.status, applied.ok
        ? {ok:true, request_id:applied.task.request_id, status:applied.task.status}
        : {ok:false, error:applied.error});
    }

    // 旧扩展可能长轮询该接口。第一阶段没有事件时立即返回空结果，避免 fetch 失败。
    if (req.method === 'GET' && p === '/api/event-wakeup') {
      if (!authOk(req, url, body, true)) return json(res, 401, {ok:false, error:'unauthorized'});
      const pending = [...state.queues.event.values()].filter(x => ['queued','pending','processing'].includes(x.status)).length;
      return json(res, 200, {
        ok:true,
        changed:pending > 0,
        pending,
        requests:[],
        updated_at:new Date().toISOString()
      });
    }

    // V6.1：资金星系读取 Edge 扩展真实板块资金快照。
    if (req.method === 'GET' && p === '/api/live-sectors') {
      if (!authOk(req, url, body, false)) return json(res, 401, {ok:false, error:'unauthorized'});
      return json(res, 200, {
        ok:true,
        source:'edge_browser_data',
        updated_at:iso(state.sectorSnapshotAt),
        age_seconds:state.sectorSnapshotAt ? Math.max(0,(Date.now()-state.sectorSnapshotAt)/1000) : null,
        count:state.sectorSnapshot.length,
        sectors:state.sectorSnapshot,
        debug:state.sectorParseDebug
      });
    }

    // 调试接口：仅本机资金星系使用。
    if (req.method === 'GET' && p === '/api/embedded-debug') {
      return json(res, 200, {
        ...statusPayload(),
        watchlist,
        has_browser_data: !!state.lastBrowserData
      });
    }

    return json(res, 404, {ok:false, error:'not found', path:p});
  });

  function start() {
    if (state.listening) return Promise.resolve(statusPayload());

    return new Promise((resolve, reject) => {
      const onError = err => {
        state.listenError = String(err?.message || err);
        state.errors.push({
          at:new Date().toISOString(),
          error:state.listenError
        });
        reject(err);
      };

      server.once('error', onError);
      server.listen(port, host, () => {
        server.removeListener('error', onError);
        state.listening = true;
        resolve(statusPayload());
      });
    });
  }

  function stop() {
    return new Promise(resolve => {
      if (!state.listening) return resolve();
      server.close(() => {
        state.listening = false;
        resolve();
      });
    });
  }

  return {
    host,
    port,
    token,
    server,
    state,
    start,
    stop,
    getStatus: statusPayload,
    getWatchlist: () => watchlist.slice(),
    setWatchlist: stocks => {
      watchlist = Array.isArray(stocks) ? stocks.slice(0,5000) : [];
    },
    getLastBrowserData: () => state.lastBrowserData,
    getSectorSnapshot: () => ({
      updatedAt:state.sectorSnapshotAt,
      sectors:state.sectorSnapshot.slice(),
      debug:{...state.sectorParseDebug}
    })
  };
}

module.exports = { createEmbeddedEdgeBridge };
