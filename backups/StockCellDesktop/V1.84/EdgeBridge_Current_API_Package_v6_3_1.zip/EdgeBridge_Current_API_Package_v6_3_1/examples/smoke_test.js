'use strict';
const { createEmbeddedEdgeBridge } = require('../edge_bridge_server');

(async () => {
  const bridge = createEmbeddedEdgeBridge({host:'127.0.0.1', port:0});
  await bridge.start();
  const port = bridge.server.address().port;
  const base = `http://127.0.0.1:${port}`;
  try {
    const health = await fetch(`${base}/api/health`).then(r=>r.json());
    if (!health.ok) throw new Error('health failed');
    const watch = await fetch(`${base}/api/watchlist`).then(r=>r.json());
    if (!watch.token) throw new Error('token missing');

    const mock = {
      sectors: [
        {f12:'BK0001', f14:'测试流入', f3:1.25, f62:1230000000},
        {f12:'BK0002', f14:'测试流出', f3:-0.80, f62:-760000000}
      ]
    };
    const posted = await fetch(`${base}/api/browser-data`, {
      method:'POST',
      headers:{'Content-Type':'application/json','X-StockTray-Token':watch.token},
      body:JSON.stringify(mock)
    }).then(r=>r.json());
    if (!posted.ok) throw new Error('browser-data failed');

    const sectors = await fetch(`${base}/api/live-sectors`, {
      headers:{'X-StockTray-Token':watch.token}
    }).then(r=>r.json());
    if (!sectors.ok || sectors.count !== 2) throw new Error('live-sectors failed');
    console.log('PASS', JSON.stringify({health, sectors}, null, 2));
  } finally {
    await bridge.stop();
  }
})().catch(err=>{ console.error(err); process.exit(1); });
