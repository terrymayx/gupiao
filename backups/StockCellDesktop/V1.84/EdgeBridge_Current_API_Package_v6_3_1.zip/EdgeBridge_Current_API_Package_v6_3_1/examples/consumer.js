'use strict';

const BASE = 'http://127.0.0.1:17890';

async function json(url, options = {}) {
  const res = await fetch(url, options);
  const body = await res.json();
  if (!res.ok || body.ok === false) {
    throw new Error(body.error || `HTTP ${res.status}`);
  }
  return body;
}

async function token() {
  const w = await json(`${BASE}/api/watchlist`, { cache: 'no-store' });
  return w.token;
}

async function status(t) {
  return json(`${BASE}/api/status`, {
    headers: { 'X-StockTray-Token': t }
  });
}

async function liveSectors(t) {
  return json(`${BASE}/api/live-sectors`, {
    headers: { 'X-StockTray-Token': t },
    cache: 'no-store'
  });
}

async function submitPeer(t, symbol, limit = 6, direction = 'inflow') {
  return json(`${BASE}/api/peer-request`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token: t, symbol, limit, direction })
  });
}

async function waitPeer(t, requestId, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const r = await json(`${BASE}/api/peer-result?request_id=${encodeURIComponent(requestId)}`, {
      headers: { 'X-StockTray-Token': t },
      cache: 'no-store'
    });
    if (r.status === 'success') return r;
    if (r.status === 'failed') throw new Error(r.error || 'peer request failed');
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  throw new Error('peer request timeout');
}

(async () => {
  console.log('health =', await json(`${BASE}/api/health`));
  const t = await token();
  console.log('status =', await status(t));

  // 实时板块资金快照（由 Edge 扩展 POST /api/browser-data 后产生）
  console.log('live sectors =', await liveSectors(t));

  // 示例：请求某板块成分股资金排名。需要 Edge 扩展在线领取任务并回传结果。
  // const q = await submitPeer(t, 'BK0450', 6, 'inflow');
  // const result = await waitPeer(t, q.request_id);
  // console.log(result.stocks);
})();
