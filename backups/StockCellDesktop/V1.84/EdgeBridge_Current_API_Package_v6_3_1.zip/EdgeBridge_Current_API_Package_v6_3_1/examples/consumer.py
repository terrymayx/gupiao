from __future__ import annotations

import json
import time
from urllib.parse import urlencode
from urllib.request import Request, urlopen

BASE = "http://127.0.0.1:17890"


def request_json(method: str, path: str, *, token=None, body=None, params=None, timeout=10):
    url = BASE + path
    if params:
        url += "?" + urlencode(params)
    headers = {"Accept": "application/json"}
    data = None
    if token:
        headers["X-StockTray-Token"] = token
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = Request(url, data=data, headers=headers, method=method)
    with urlopen(req, timeout=timeout) as r:
        out = json.loads(r.read().decode("utf-8"))
    if out.get("ok") is False:
        raise RuntimeError(out.get("error") or "EdgeBridge error")
    return out


def get_token():
    return request_json("GET", "/api/watchlist")["token"]


def live_sectors(token):
    return request_json("GET", "/api/live-sectors", token=token)


def fetch_peer_stocks(token, board_code="BK0450", limit=6, direction="inflow", timeout=30):
    q = request_json(
        "POST",
        "/api/peer-request",
        body={"token": token, "symbol": board_code, "limit": limit, "direction": direction},
    )
    request_id = q["request_id"]
    deadline = time.time() + timeout
    while time.time() < deadline:
        result = request_json(
            "GET",
            "/api/peer-result",
            token=token,
            params={"request_id": request_id},
        )
        if result.get("status") == "success":
            return result
        if result.get("status") == "failed":
            raise RuntimeError(result.get("error") or "peer request failed")
        time.sleep(0.5)
    raise TimeoutError("peer request timeout")


if __name__ == "__main__":
    print(request_json("GET", "/api/health"))
    t = get_token()
    print(request_json("GET", "/api/status", token=t))
    print(live_sectors(t))
    # print(fetch_peer_stocks(t, "BK0450", 6, "inflow"))
