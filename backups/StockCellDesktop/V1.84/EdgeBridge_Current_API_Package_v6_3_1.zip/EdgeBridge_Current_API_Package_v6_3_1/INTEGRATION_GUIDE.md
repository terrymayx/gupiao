# Integration Guide - reuse the current EdgeBridge in another program

## Scenario 1: consume the bridge that Stock Galaxy already started

This is the easiest and safest approach.

1. Start Stock Galaxy V6.3.1 normally.
2. Keep Edge + the existing extension enabled.
3. Other program checks `GET http://127.0.0.1:17890/api/health`.
4. Other program gets token from `GET /api/watchlist`.
5. Read `/api/status` and `/api/live-sectors` or submit a task.

Do not start `standalone_bridge.js` in this scenario because port 17890 is already owned.

## Scenario 2: the other program owns the bridge

1. Copy this package into the target project.
2. Make sure Node.js 20+ is installed.
3. Start `node standalone_bridge.js`.
4. Keep the existing Edge extension enabled.
5. Check `/api/status` until `edge_extension_connected` becomes true.
6. Use the consumer endpoints.

## Recommended startup check

```text
health -> watchlist/token -> status
```

If `health` fails: no bridge is listening.

If `health` works but `edge_extension_connected=false`: bridge exists, but Edge extension has not recently contacted it.

If a task remains pending: confirm Edge and the extension are active and able to reach 127.0.0.1:17890.

## Read sector fund-flow snapshot

```javascript
const base = 'http://127.0.0.1:17890';
const w = await fetch(base + '/api/watchlist').then(r=>r.json());
const sectors = await fetch(base + '/api/live-sectors', {
  headers: {'X-StockTray-Token': w.token},
  cache: 'no-store'
}).then(r=>r.json());

const inflow = sectors.sectors
  .filter(x => x.flow > 0)
  .sort((a,b)=>b.flow-a.flow);

const outflow = sectors.sectors
  .filter(x => x.flow < 0)
  .sort((a,b)=>a.flow-b.flow);
```

`flow` is already in 亿元.

## Fetch a board's constituent ranking through the extension queue

```javascript
const submitted = await fetch(base + '/api/peer-request', {
  method:'POST',
  headers:{'Content-Type':'application/json'},
  body:JSON.stringify({
    token:w.token,
    symbol:'BK0450',
    limit:6,
    direction:'inflow'
  })
}).then(r=>r.json());

// poll /api/peer-result every ~500 ms
```

For inflow and outflow together, submit two requests (`direction: inflow` and `direction: outflow`) and merge/deduplicate by stock code in your program.

## Token refresh

The bridge generates a new token when its process starts. Never hard-code it.

On 401:

1. call `/api/watchlist` again;
2. replace cached token;
3. retry the consumer request once.

## Port

Default: `17890`.

Standalone mode supports environment variables:

```text
EDGE_BRIDGE_HOST=127.0.0.1
EDGE_BRIDGE_PORT=17890
```

Changing the port only works if the Edge extension is also configured to contact that port. With the existing extension, keep 17890.

## Local security

Keep the bridge on `127.0.0.1`. Do not expose it on `0.0.0.0` or the public network. The session token is intended as local process coordination, not as Internet-grade authentication.
