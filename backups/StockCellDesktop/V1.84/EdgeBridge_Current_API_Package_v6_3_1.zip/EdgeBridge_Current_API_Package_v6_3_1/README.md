# Current EdgeBridge reusable package - V6.3.1

This folder is copied from the **current Stock Galaxy V6.3.1 embedded EdgeBridge** implementation. It is intended for another local program to reuse the same Microsoft Edge extension data path without running the Stock Galaxy UI.

## 1. Architecture

```text
Other local program
        |
        | HTTP JSON (127.0.0.1:17890)
        v
Current EdgeBridge (this package)
        ^
        | existing Edge extension protocol
        |
Microsoft Edge extension
        |
        v
market/data pages and APIs used by the extension
```

The bridge binds only to `127.0.0.1` by default. The current default port is **17890**.

Important: only one process can own port 17890 at a time. If Stock Galaxy V6.3.1 is already running and owns the bridge, another program should **consume the existing HTTP API** instead of starting a second bridge.

## 2. Fastest way for another program

### Mode A - Stock Galaxy is already running

Do not start `standalone_bridge.js`. Directly connect to:

```text
http://127.0.0.1:17890
```

Flow:

```text
GET /api/health
GET /api/watchlist              -> obtain current session token
GET /api/status                 -> send X-StockTray-Token
GET /api/live-sectors           -> current parsed sector capital-flow snapshot
POST /api/peer-request          -> submit a board constituent ranking task
GET /api/peer-result?...        -> poll until success / failed
```

### Mode B - Another program runs the bridge itself

Requirements:

- Windows / macOS / Linux with Node.js 20+ (Windows is the tested target of the Stock Galaxy project)
- Microsoft Edge
- The same existing Edge extension that speaks this bridge protocol

Start:

```bash
node standalone_bridge.js
```

On Windows you can double-click:

```text
start_bridge.bat
```

Then keep the process alive. The Edge extension connects to `127.0.0.1:17890` and posts/pulls data through the internal endpoints.

## 3. Token usage

`GET /api/health` and `GET /api/watchlist` do not require a token.

`GET /api/watchlist` returns a random token for the current bridge process:

```json
{
  "ok": true,
  "token": "...",
  "stocks": []
}
```

For normal consumer APIs, send it in one of these forms:

```http
X-StockTray-Token: <token>
```

or in a JSON request body as `token`.

The token changes every time the bridge process restarts. Consumers should reacquire it from `/api/watchlist` after a 401 or reconnect.

## 4. Most useful current API for sector flow

### GET `/api/live-sectors`

Requires token.

This is the current Stock Galaxy endpoint used to expose sector capital-flow data extracted from the Edge extension's latest `/api/browser-data` payload.

Example response:

```json
{
  "ok": true,
  "source": "edge_browser_data",
  "updated_at": "2026-08-30T05:00:00.000Z",
  "age_seconds": 0.8,
  "count": 2,
  "sectors": [
    {
      "name": "半导体",
      "code": "BK1036",
      "flow": 98.7,
      "pct": 1.35,
      "source_field": "f62",
      "source_path": "browserData.sectors[0]"
    }
  ]
}
```

`flow` is normalized to **亿元** by the bridge. Positive means net inflow; negative means net outflow.

The bridge recognizes common field names including `f12/f14/f3/f62`, `net_inflow`, `netFlow`, `mainNetInflow`, board/industry/sector naming variants, and recursively searches sector/industry/board/plate-shaped data inside the posted browser payload.

## 5. Board constituent-stock task

### POST `/api/peer-request`

Requires token.

```json
{
  "token": "<token>",
  "symbol": "BK0450",
  "limit": 6,
  "direction": "inflow"
}
```

The current protocol accepts `direction` values such as `inflow` / `outflow`; the Edge extension is responsible for claiming and executing the queued task.

Initial response:

```json
{
  "ok": true,
  "request_id": "peer_xxx",
  "symbol": "BK0450",
  "limit": 6,
  "direction": "inflow",
  "status": "queued"
}
```

Then poll:

```text
GET /api/peer-result?request_id=peer_xxx
X-StockTray-Token: <token>
```

Pending:

```json
{
  "ok": true,
  "status": "pending",
  "stocks": []
}
```

Success:

```json
{
  "ok": true,
  "status": "success",
  "stocks": [
    {
      "name": "股票名",
      "code": "600000",
      "change_percent": -1.25,
      "net_inflow": -123456789
    }
  ]
}
```

## 6. Public consumer endpoints

| Method | Endpoint | Token | Purpose |
|---|---|---:|---|
| GET | `/api/health` | No | bridge alive check |
| GET | `/api/watchlist` | No | obtain session token and watchlist |
| GET | `/api/status` | Yes | bridge + Edge extension connection/status |
| GET | `/api/live-sectors` | Yes | current sector fund-flow snapshot parsed from browser-data |
| POST | `/api/industry-request` | Yes | enqueue industry/history task |
| GET | `/api/industry-result?request_id=...` | Yes | poll industry result |
| POST | `/api/peer-request` | Yes | enqueue board constituent-stock ranking task |
| GET | `/api/peer-result?request_id=...` | Yes | poll peer-stock result |
| POST | `/api/event-request` | Yes | enqueue shareholders/corporate-actions task |
| GET | `/api/event-result?request_id=...` | Yes | poll event result |

## 7. Edge-extension internal endpoints

These are part of the current protocol but **ordinary programs should not consume them**. They are for the Edge extension to post data, claim queued jobs, and return results.

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/browser-data` | extension posts current browser/market payload |
| GET | `/api/industry-requests?limit=5` | extension claims industry jobs |
| POST | `/api/industry-data` | extension returns industry job result |
| GET | `/api/peer-requests?limit=5` | extension claims peer jobs |
| POST | `/api/peer-data` | extension returns peer job result |
| GET | `/api/event-requests?limit=5` | extension claims event jobs |
| POST | `/api/event-data` | extension returns event result |
| GET | `/api/event-wakeup` | extension event wakeup compatibility endpoint |

The bridge allows an extension-originated internal request without an explicit token when it looks like a Chrome/Edge extension request and no wrong token was supplied. Normal consumer endpoints still require the token.

## 8. Status fields

`GET /api/status` includes useful fields such as:

```json
{
  "ok": true,
  "running": true,
  "provider": "edge_tencent",
  "embedded": true,
  "bridge_owner": "stock_galaxy",
  "port": 17890,
  "edge_extension_connected": true,
  "last_extension_at": "...",
  "last_extension_path": "/api/browser-data",
  "last_browser_data_at": "...",
  "request_count": 123,
  "peer_queue": {
    "queued": 0,
    "processing": 0,
    "success": 2,
    "failed": 0
  },
  "cache_age": {},
  "errors": []
}
```

The current bridge considers the Edge extension connected when it has seen extension activity within roughly the last 30 seconds.

## 9. Embed directly in another Node/Electron program

Instead of starting a separate process:

```js
const { createEmbeddedEdgeBridge } = require('./edge_bridge_server');

const bridge = createEmbeddedEdgeBridge({
  host: '127.0.0.1',
  port: 17890,
  watchlist: [
    { key: 'A股:600519', symbol: 'sh600519' }
  ]
});

await bridge.start();
console.log(bridge.getStatus());

// Node-only direct access to the latest raw payload posted by the extension:
console.log(bridge.getLastBrowserData());

// Parsed sector snapshot used by Stock Galaxy:
console.log(bridge.getSectorSnapshot());
```

The module also exposes `setWatchlist`, `getWatchlist`, `start`, and `stop`.

## 10. Files in this package

```text
edge_bridge_server.js        exact current V6.3.1 bridge module
standalone_bridge.js         independent Node launcher
start_bridge.bat             Windows launcher
API_REFERENCE.md             endpoint reference
INTEGRATION_GUIDE.md         recommended integration flow
examples/consumer.js         Node.js consumer example
examples/consumer.py         Python standard-library consumer example
examples/smoke_test.js       local protocol smoke test
```

## 11. Important distinction

This package is the **Edge bridge layer**. It does not replace the existing Edge extension's collection logic. For queued `industry/peer/event` tasks to complete, the Edge extension must be active and able to reach this bridge.

For a program that only wants to read the bridge while Stock Galaxy is already running, simply call the HTTP consumer endpoints; do not start another server on port 17890.
