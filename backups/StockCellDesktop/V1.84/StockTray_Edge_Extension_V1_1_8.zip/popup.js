const bridge = document.getElementById("bridge");
const sync = document.getElementById("sync");
const status = document.getElementById("status");
const button = document.getElementById("syncNow");

async function refreshStatus() {
  try {
    const response = await fetch("http://127.0.0.1:17890/api/health", { cache: "no-store" });
    bridge.textContent = response.ok ? "已连接" : "未连接";
  } catch (_) { bridge.textContent = "未连接（请先启动 StockTray）"; }
  const data = await chrome.storage.local.get(["lastSync", "lastError"]);
  sync.textContent = data.lastSync ? new Date(data.lastSync).toLocaleString() : "尚未同步";
  if (data.lastError && data.lastError.length) status.textContent = `最近有 ${data.lastError.length} 项请求失败，将自动重试`;
}

button.addEventListener("click", async () => {
  button.disabled = true;
  status.textContent = "正在获取腾讯行情…";
  try {
    const result = await chrome.runtime.sendMessage({ type: "syncNow" });
    status.textContent = result && result.error ? result.error : "获取完成";
  } catch (error) { status.textContent = String(error); }
  button.disabled = false;
  refreshStatus();
});

refreshStatus();
