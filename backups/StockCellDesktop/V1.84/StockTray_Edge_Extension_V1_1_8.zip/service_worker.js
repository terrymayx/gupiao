const BRIDGE_URL = "http://127.0.0.1:17890";
const ALARM_NAME = "stocktray-tencent-sync";
const POLL_MINUTES = 0.5;
const QUOTE_URL = "https://qt.gtimg.cn/q=";
const INTRADAY_URL = "https://ifzq.gtimg.cn/appstock/app/minute/query?code=";
const EASTMONEY_MARKET_URL = "https://push2.eastmoney.com/api/qt/ulist.np/get";
let syncInFlight = null;
let lastStockSyncAt = 0;
let lastMarketSyncAt = 0;
let lastSectorSyncAt = 0;
let queueSyncInFlight = null;
let eventWakeInFlight = null;
let eventSyncInFlight = null;
let eventWakeGeneration = 0;
const EASTMONEY_SECTOR_FLOW_URL = "https://data.eastmoney.com/dataapi/bkzj/getbkzj";
const EASTMONEY_KLINE_URL = "https://push2his.eastmoney.com/api/qt/stock/kline/get";
const EASTMONEY_CONSTITUENTS_URL = "https://push2.eastmoney.com/api/qt/clist/get";
const FIXED_EASTMONEY_INDUSTRY_API_URL = "https://push2his.eastmoney.com/api/qt/stock/kline/get?secid=90.BK0450&ut=fa5fd1943c7b386f172d6893dbfba10b&fields1=f1%2Cf2%2Cf3%2Cf4%2Cf5%2Cf6&fields2=f51%2Cf52%2Cf53%2Cf54%2Cf55%2Cf56%2Cf57%2Cf58%2Cf59%2Cf60%2Cf61&klt=101&fqt=1&end=20260821&lmt=10000&beg=20160101";
const EASTMONEY_EVENT_API_URL = "https://datacenter-web.eastmoney.com/api/data/v1/get";

const EASTMONEY_STOCK_GET_URL = "https://push2.eastmoney.com/api/qt/stock/get";

function normalizeSixDigitCode(value) {
  const match = String(value || "").match(/(\d{6})(?!.*\d)/);
  return match ? match[1] : "";
}

function stockSecidFromCode(code) {
  const c = normalizeSixDigitCode(code);
  if (!c) return "";
  return `${/^[569]/.test(c) ? 1 : 0}.${c}`;
}

async function fetchRequestedStockMeta(watchlist) {
  const code = normalizeSixDigitCode(watchlist?.requested_code);
  if (!code || !watchlist?.force_refresh) return null;

  const fields = [
    "f57","f58","f127",
    "f43","f44","f45","f46","f60",
    "f48","f137",
    "f168","f169","f170","f171"
  ].join(",");

  const params = new URLSearchParams({
    fltt:"2",
    invt:"2",
    secid:stockSecidFromCode(code),
    fields,
    ut:"fa5fd1943c7b386f172d6893dbbd1d0c"
  });

  const url = `${EASTMONEY_STOCK_GET_URL}?${params.toString()}`;
  const payload = await fetchEastmoneyJson(url);
  const data = payload?.data || null;

  if (!data || normalizeSixDigitCode(data.f57) !== code) {
    throw new Error(`自定义个股 ${code} 东方财富补充信息为空`);
  }

  return {
    code,
    source:"eastmoney_stock_get_extension",
    url,
    data
  };
}


function createTimingTrace(name) {
  const started = performance.now();
  let previous = started;
  const steps = [];
  return {
    mark(step, details = {}) {
      const now = performance.now();
      steps.push({
        step,
        duration_ms: Math.round((now - previous) * 10) / 10,
        elapsed_ms: Math.round((now - started) * 10) / 10,
        ...details
      });
      previous = now;
    },
    finish(details = {}) {
      return {
        name,
        total_elapsed_ms: Math.round((performance.now() - started) * 10) / 10,
        steps,
        ...details
      };
    }
  };
}

async function decodeTencentText(response) {
  const bytes = await response.arrayBuffer();
  for (const encoding of ["gb18030", "utf-8"]) {
    try {
      const text = new TextDecoder(encoding, { fatal: false }).decode(bytes);
      if (encoding === "utf-8" && text.includes("\ufffd")) continue;
      return text;
    } catch (_) {}
  }
  return new TextDecoder().decode(bytes);
}

async function fetchWithTimeout(url, options = {}) {
  const timeoutMs = Number(options.timeoutMs) || 8000;
  const requestOptions = { ...options };
  delete requestOptions.timeoutMs;
  const controller = new AbortController();
  const timer = timeoutMs === 8000
    ? setTimeout(() => controller.abort(), 8000)
    : setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...requestOptions, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function fetchTencentText(url) {
  const response = await fetchWithTimeout(url, { cache: "no-store", credentials: "omit" });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return decodeTencentText(response);
}

async function fetchTencentJson(url) {
  const response = await fetchWithTimeout(url, { cache: "no-store", credentials: "omit" });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}

async function fetchEastmoneyJson(url) {
  const response = await fetchWithTimeout(url, { cache: "no-store", credentials: "omit" });
  const text = await response.text();
  const debug = {
    url,
    status: response.status,
    content_type: response.headers.get("content-type") || "",
    body_preview: text.slice(0, 2000)
  };
  if (!response.ok) {
    const error = new Error(`HTTP ${response.status}`);
    error.debug = debug;
    throw error;
  }
  try {
    return JSON.parse(text);
  } catch (_) {
    const start = text.indexOf("(");
    const end = text.lastIndexOf(")");
    if (start >= 0 && end > start) return JSON.parse(text.slice(start + 1, end));
    const error = new Error("东方财富资金流向接口返回格式无效");
    error.debug = debug;
    throw error;
  }
}

async function getWatchlist() {
  const response = await fetchWithTimeout(`${BRIDGE_URL}/api/watchlist`, { cache: "no-store" });
  if (!response.ok) throw new Error(`StockTray 桥接不可用（HTTP ${response.status}）`);
  return response.json();
}

function findSectorRows(value) {
  if (Array.isArray(value)) return value;
  if (!value || typeof value !== "object") return [];
  for (const key of ["data", "diff", "list", "rows", "rank_list", "result"]) {
    const rows = findSectorRows(value[key]);
    if (rows.length) return rows;
  }
  return [];
}

function normalizeSectorRows(payload) {
  const rows = findSectorRows(payload);
  return rows.map(row => ({
    name: row ? (row.name || row.ptname || row.title || row.f14 || row.board_name || "") : "",
    zdf: row ? (row.zdf ?? row.change_percent ?? row.priceRatio ?? row.f3 ?? row.zf ?? "") : "",
    net_inflow: row ? (row.zljlr ?? row.net_inflow ?? row.main_net_inflow ?? "") : "",
    code: row ? (row.code || row.ptcode || row.pt_code || row.id || "") : ""
  })).filter(row => row.name && (row.zdf !== "" || row.net_inflow !== ""));
}

async function fetchEastmoneyFundRows() {
  const params = new URLSearchParams({
    key: "f62",
    code: "m:90+s:4"
  });
  const apiUrl = `${EASTMONEY_SECTOR_FLOW_URL}?${params.toString()}`;
  let tab;
  let payload;
  try {
    tab = await chrome.tabs.create({ url: apiUrl, active: false });
    await waitForIndustryTab(tab.id, 30000);
    const executed = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => ({
        text: document.body?.innerText || document.documentElement?.innerText || "",
        title: document.title || "",
        url: location.href || "",
        ready_state: document.readyState || ""
      })
    });
    const page = executed?.[0]?.result || {};
    try {
      payload = parseEastmoneyPageText(page.text);
    } catch (error) {
      error.debug = {
        url: apiUrl,
        api_mode: "page_navigation",
        page_url: page.url || apiUrl,
        page_title: page.title || "",
        ready_state: page.ready_state || "",
        body_length: String(page.text || "").length,
        body_preview: String(page.text || "").slice(0, 2000)
      };
      throw error;
    }
  } finally {
    if (tab?.id != null) try { await chrome.tabs.remove(tab.id); } catch (_) {}
  }
  const rows = findSectorRows(payload).map(row => ({
    name: row ? (row.f14 || row.name || row.ptname || "") : "",
    zdf: row ? (row.f3 ?? row.zdf ?? row.change_percent ?? "") : "",
    net_inflow: row ? (row.f62 ?? row.zljlr ?? row.net_inflow ?? "") : "",
    code: row ? (row.f12 || row.code || row.ptcode || "") : ""
  })).filter(row => row.name && row.net_inflow !== "");
  if (!rows.length) {
    const error = new Error("东方财富资金流向接口没有返回有效数据");
    error.debug = {
      url: apiUrl,
      payload_keys: payload && typeof payload === "object" ? Object.keys(payload) : [],
      payload_preview: JSON.stringify(payload).slice(0, 2000)
    };
    throw error;
  }
  return rows;
}

function serializeRequestError(kind, error) {
  const result = { kind, message: String(error) };
  if (error && error.debug) result.debug = error.debug;
  return result;
}

function sortSectorRows(rows, field) {
  return [...rows].sort((left, right) => {
    const leftValue = Number(left[field]);
    const rightValue = Number(right[field]);
    if (!Number.isFinite(leftValue)) return 1;
    if (!Number.isFinite(rightValue)) return -1;
    return rightValue - leftValue;
  });
}

function buildSectorColumns(rows) {
  const sortedPriceRows = sortSectorRows(rows, "zdf");
  const sortedDeclineRows = [...rows].sort((left, right) => Number(left.zdf) - Number(right.zdf));
  const firstTenFundRows = rows.slice(0, 10);
  const lastTenFundRows = rows.slice(-10);
  return {
    gainers: sortedPriceRows.slice(0, 10),
    losers: sortedDeclineRows.slice(0, 10),
    fund_gainers: firstTenFundRows.filter(row => Number(row.net_inflow) >= 0),
    fund_losers: lastTenFundRows.filter(row => Number(row.net_inflow) < 0)
  };
}

async function syncSectorData() {
  try {
    const rows = await fetchEastmoneyFundRows();
    return { ...buildSectorColumns(rows), errors: [] };
  } catch (error) {
    return {
      gainers: null,
      losers: null,
      fund_gainers: null,
      fund_losers: null,
      errors: [serializeRequestError("sector_fund", error)]
    };
  }
}

function parseEastmoneyPageText(text) {
  const normalized = String(text || "").trim();
  if (!normalized) throw new Error("东方财富页面返回空数据");
  try {
    return JSON.parse(normalized);
  } catch (_) {
    const start = normalized.indexOf("(");
    const end = normalized.lastIndexOf(")");
    if (start >= 0 && end > start) return JSON.parse(normalized.slice(start + 1, end));
    throw new Error("东方财富页面返回格式无效");
  }
}

async function postBrowserData(watchlist, payload) {
  const response = await fetchWithTimeout(`${BRIDGE_URL}/api/browser-data`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      token: watchlist.token,
      extension: {
        name: chrome.runtime.getManifest().name,
        version: chrome.runtime.getManifest().version
      },
      quotes: [],
      intraday: [],
      sector: null,
      errors: [],
      ...payload
    })
  });
  if (!response.ok) throw new Error(`StockTray bridge POST failed (HTTP ${response.status})`);
  return response;
}

async function syncStockData(stocks) {
  const results = await Promise.all(stocks.map(async (stock) => {
    const result = { quotes: [], intraday: [], errors: [] };
    const [quoteResult, intradayResult] = await Promise.allSettled([
      fetchTencentText(`${QUOTE_URL}${encodeURIComponent(stock.symbol)}`),
      fetchTencentJson(`${INTRADAY_URL}${encodeURIComponent(stock.symbol)}`)
    ]);
    if (quoteResult.status === "fulfilled") {
      result.quotes.push({ key: stock.key, payload: { raw_text: quoteResult.value, symbol: stock.symbol } });
    } else {
      result.errors.push({ kind: "quote", key: stock.key, message: String(quoteResult.reason) });
    }
    if (intradayResult.status === "fulfilled") {
      result.intraday.push({ key: stock.key, payload: intradayResult.value });
    } else {
      result.errors.push({ kind: "intraday", key: stock.key, message: String(intradayResult.reason) });
    }
    return result;
  }));
  return results.reduce((merged, result) => {
    merged.quotes.push(...result.quotes);
    merged.intraday.push(...result.intraday);
    merged.errors.push(...result.errors);
    return merged;
  }, { quotes: [], intraday: [], errors: [] });
}

function buildIndustryUrl(symbol) {
  const normalized = String(symbol || "").toUpperCase();
  if (!/^BK\d{4}$/.test(normalized)) throw new Error("无效行业指数代码");
  return `https://quote.eastmoney.com/bk/90.${normalized}.html#fullScreenChart`;
}

function asJsonValue(value) {
  if (typeof value !== "string") return value;
  const text = value.trim();
  if (!text) return null;
  try { return JSON.parse(text); } catch (_) {}
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start >= 0 && end > start) {
    try { return JSON.parse(text.slice(start, end + 1)); } catch (_) {}
  }
  return null;
}

function collectIndustryArrays(value, output = []) {
  value = asJsonValue(value);
  if (Array.isArray(value)) {
    if (value.length && (Array.isArray(value[0]) || (value[0] && typeof value[0] === "object"))) output.push(value);
    for (const item of value) collectIndustryArrays(item, output);
    return output;
  }
  if (!value || typeof value !== "object") return output;
  for (const [key, item] of Object.entries(value)) {
    if (key.length <= 100) collectIndustryArrays(item, output);
  }
  return output;
}

function normalizeIndustryDate(value) {
  const numeric = Number(value);
  if (Number.isFinite(numeric) && numeric > 100000000000) {
    const timestamp = new Date(numeric + 8 * 60 * 60 * 1000);
    if (!Number.isNaN(timestamp.getTime())) return timestamp.toISOString().slice(0, 10);
  }
  const text = String(value ?? "").trim().replace(/[./]/g, "-");
  const match = text.match(/(\d{4}-\d{1,2}-\d{1,2})/);
  if (!match) return "";
  const parts = match[1].split("-").map(Number);
  return parts.length === 3 && parts[0] && parts[1] && parts[2]
    ? `${parts[0]}-${String(parts[1]).padStart(2, "0")}-${String(parts[2]).padStart(2, "0")}` : "";
}

function normalizeIndustryRow(row) {
  if (Array.isArray(row)) {
    const date = normalizeIndustryDate(row[0]);
    const timestampPoint = Number(row[0]) > 100000000000;
    const close = Number(timestampPoint ? row[1] : (row[2] ?? row[1]));
    const pct = Number(timestampPoint ? row[2] : (row[8] ?? row[6] ?? row[5]));
    return date && Number.isFinite(close) ? { date, close, pct_change: Number.isFinite(pct) ? pct : null } : null;
  }
  if (!row || typeof row !== "object") return null;
  const date = normalizeIndustryDate(row.date ?? row.day ?? row.f51 ?? row.trade_date ?? row.x);
  const close = Number(row.close ?? row.price ?? row.f54 ?? row.value ?? row.y);
  const pct = Number(row.pct_change ?? row.change_percent ?? row.zdf ?? row.f57 ?? row.change);
  return date && Number.isFinite(close) ? { date, close, pct_change: Number.isFinite(pct) ? pct : null } : null;
}

function extractIndustryRows(pageValue, request) {
  const candidates = [];
  for (const value of [pageValue, pageValue?.result, pageValue?.globals, pageValue?.resources]) collectIndustryArrays(value, candidates);
  const unique = new Map();
  for (const candidate of candidates) {
    for (const row of candidate) {
      const normalized = normalizeIndustryRow(row);
      if (!normalized || normalized.date < request.start || normalized.date > request.end) continue;
      unique.set(normalized.date, normalized);
    }
  }
  const rows = [...unique.values()].sort((a, b) => a.date.localeCompare(b.date));
  for (let index = 0; index < rows.length; index += 1) {
    if (rows[index].pct_change == null && index > 0 && rows[index - 1].close) rows[index].pct_change = (rows[index].close / rows[index - 1].close - 1) * 100;
  }
  return rows;
}

function extractIndustryApiRows(payload, request) {
  const rawRows = payload?.data?.klines;
  if (!Array.isArray(rawRows)) return [];
  const unique = new Map();
  for (const raw of rawRows) {
    const row = typeof raw === "string" ? raw.split(",") : raw;
    const normalized = normalizeIndustryRow(row);
    if (!normalized || normalized.date < request.start || normalized.date > request.end) continue;
    unique.set(normalized.date, normalized);
  }
  const rows = [...unique.values()].sort((a, b) => a.date.localeCompare(b.date));
  for (let index = 0; index < rows.length; index += 1) {
    if (rows[index].pct_change == null && index > 0 && rows[index - 1].close) {
      rows[index].pct_change = (rows[index].close / rows[index - 1].close - 1) * 100;
    }
  }
  return rows;
}

function findIndustryApiTemplateUrl(resourceUrls) {
  if (!Array.isArray(resourceUrls)) return "";
  for (const candidate of [...resourceUrls].reverse()) {
    try {
      const url = new URL(String(candidate));
      if (url.hostname.toLowerCase() === "push2his.eastmoney.com" && /\/api\/qt\/stock\/kline\/get$/i.test(url.pathname)) return url.toString();
    } catch (_) {}
  }
  return "";
}

function normalizeIndustryApiEndDate(value) {
  const raw = String(value || "").trim();
  const parsed = new Date(`${raw}T00:00:00Z`);
  if (Number.isNaN(parsed.getTime())) return raw.replaceAll("-", "");
  while (parsed.getUTCDay() === 0 || parsed.getUTCDay() === 6) parsed.setUTCDate(parsed.getUTCDate() - 1);
  return parsed.toISOString().slice(0, 10).replaceAll("-", "");
}

function buildIndustryApiUrl(request, templateUrl = "") {
  if (request.fixed_api) return FIXED_EASTMONEY_INDUSTRY_API_URL;
  let url;
  try {
    url = templateUrl ? new URL(templateUrl) : new URL(EASTMONEY_KLINE_URL);
  } catch (_) {
    url = new URL(EASTMONEY_KLINE_URL);
  }
  url.searchParams.set("secid", `90.${request.symbol}`);
  url.searchParams.set("beg", String(request.start).replaceAll("-", ""));
  url.searchParams.set("end", normalizeIndustryApiEndDate(request.end));
  url.searchParams.set("lmt", "10000");
  // The page may use JSONP/cache-busting parameters; fetch() needs plain JSON.
  url.searchParams.delete("cb");
  url.searchParams.delete("_");
  return url.toString();
}

function summarizeIndustryApiPayload(payload) {
  const data = payload && typeof payload === "object" ? payload.data : null;
  const rawRows = data && Array.isArray(data.klines) ? data.klines : [];
  const preview = value => value == null ? null : String(value).slice(0, 500);
  return {
    payload_type: typeof payload,
    top_keys: payload && typeof payload === "object" ? Object.keys(payload).slice(0, 20) : [],
    data_keys: data && typeof data === "object" ? Object.keys(data).slice(0, 30) : [],
    kline_count: rawRows.length,
    first_kline: rawRows.length ? preview(rawRows[0]) : null,
    last_kline: rawRows.length ? preview(rawRows[rawRows.length - 1]) : null,
    total: data && data.total != null ? data.total : null
  };
}
async function fetchIndustryApi(request, templateUrl = "") {
  const apiUrl = buildIndustryApiUrl(request, templateUrl);
  const response = await fetchWithTimeout(apiUrl, { cache: "no-store", credentials: "omit" });
  if (!response.ok) throw new Error(`东方财富历史行业 K 线 HTTP ${response.status}`);
  const payload = await response.json();
  const responseDebug = summarizeIndustryApiPayload(payload);
  const rows = extractIndustryApiRows(payload, request);
  if (!rows.length) {
    const error = new Error("东方财富历史行业 K 线接口未返回有效日期序列");
    error.debug = responseDebug;
    throw error;
  }
  return { rows, apiUrl, responseDebug };
}

function parseIndustryApiText(text) {
  const normalized = String(text || "").trim();
  if (!normalized) throw new Error("Edge 接口页面返回空正文");
  try {
    return JSON.parse(normalized);
  } catch (_) {
    const match = normalized.match(/^[A-Za-z_$][\w$]*\((.*)\)\s*;?$/s);
    if (!match) throw new Error("Edge 接口页面返回不是 JSON/JSONP");
    return JSON.parse(match[1]);
  }
}

async function fetchIndustryApiByEdgePage(request, templateUrl = "") {
  const apiUrl = buildIndustryApiUrl(request, templateUrl);
  const apiTab = await chrome.tabs.create({ url: apiUrl, active: false });
  try {
    await waitForIndustryTab(apiTab.id, 30000);
    const executed = await chrome.scripting.executeScript({
      target: { tabId: apiTab.id },
      func: () => ({
        text: document.body?.innerText || document.documentElement?.innerText || "",
        title: document.title,
        url: location.href
      })
    });
    const page = executed?.[0]?.result || {};
    const bodyText = String(page.text || "").trim();
    let payload;
    try {
      payload = parseIndustryApiText(bodyText);
    } catch (error) {
      error.debug = { page_url: page.url || apiUrl, page_title: page.title || "", body_length: bodyText.length, body_preview: bodyText.slice(0, 1000) };
      throw error;
    }
    const responseDebug = { page_url: page.url || apiUrl, page_title: page.title || "", body_length: bodyText.length, ...summarizeIndustryApiPayload(payload) };
    const rows = extractIndustryApiRows(payload, request);
    if (!rows.length) {
      const error = new Error("Edge 接口页面返回的 JSON 没有有效日期序列");
      error.debug = responseDebug;
      throw error;
    }
    return { rows, apiUrl, mode: "page_navigation", responseDebug };
  } finally {
    if (apiTab?.id != null) try { await chrome.tabs.remove(apiTab.id); } catch (_) {}
  }
}
async function fetchIndustryApiInPage(tabId, request, templateUrl = "") {
  if (tabId == null) throw new Error("行业页面标签页不可用");
  const apiUrl = buildIndustryApiUrl(request, templateUrl);
  const executed = await chrome.scripting.executeScript({
    target: { tabId },
    func: (plainUrl) => new Promise((resolve, reject) => {
      const callbackName = `__stockTrayIndustryKline_${Date.now()}_${Math.floor(Math.random() * 1000000)}`;
      const url = new URL(plainUrl);
      url.searchParams.set("cb", callbackName);
      url.searchParams.set("_", String(Date.now()));
      const script = document.createElement("script");
      const timer = setTimeout(() => finish(new Error("东方财富 JSONP 行业 K 线请求超时")), 15000);
      const finish = (error, payload) => {
        clearTimeout(timer);
        script.remove();
        try { delete window[callbackName]; } catch (_) { window[callbackName] = undefined; }
        error ? reject(error) : resolve(payload);
      };
      window[callbackName] = payload => finish(null, payload);
      script.onerror = () => finish(new Error("东方财富 JSONP 行业 K 线请求失败"));
      script.async = true;
      script.src = url.toString();
      (document.head || document.documentElement).appendChild(script);
    }),
    args: [apiUrl]
  });
  const payload = executed?.[0]?.result;
  const responseDebug = summarizeIndustryApiPayload(payload);
  const rows = extractIndustryApiRows(payload, request);
  if (!rows.length) {
    const error = new Error("东方财富 JSONP 行业 K 线接口未返回有效日期序列");
    error.debug = responseDebug;
    throw error;
  }
  return { rows, apiUrl, mode: "page_jsonp", responseDebug };
}

function buildIndustryConstituentUrl(symbol, limit = 10, direction = "inflow") {
  const normalized = String(symbol || "").toUpperCase();
  if (!/^BK\d{4}$/.test(normalized)) throw new Error("无效行业指数代码");
  const normalizedDirection = String(direction || "inflow").toLowerCase();
  if (!["inflow", "outflow", "gain", "decline"].includes(normalizedDirection)) throw new Error("无效板块排序方向");

  // V1.1.8：兼容原 peer 资金流排序，同时支持桌面板块展开使用涨跌幅 TOP10。
  const byChange = normalizedDirection === "gain" || normalizedDirection === "decline";
  const descending = normalizedDirection === "inflow" || normalizedDirection === "gain";

  const params = new URLSearchParams({
    pn: "1",
    pz: "50",
    po: descending ? "1" : "0",
    np: "1",
    fltt: "2",
    invt: "2",
    fid: byChange ? "f3" : "f62",
    fs: `b:${normalized}`,
    fields: "f12,f14,f2,f3,f62,f184,f66,f69,f72,f75,f78,f81,f84,f87,f204,f205,f124,f1,f13",
    ut: "8dec03ba335b81bf4ebdf7b29ec27d15"
  });
  return `${EASTMONEY_CONSTITUENTS_URL}?${params.toString()}`;
}

function extractIndustryConstituentSymbols(payload, limit = 10) {
  return extractIndustryConstituentRows(payload, limit).map(row => row.code);
}

function extractIndustryConstituentRows(payload, limit = 10) {
  let rows = payload?.data?.diff || [];
  if (rows && !Array.isArray(rows) && typeof rows === "object") rows = Object.values(rows);
  const stocks = [];
  for (const row of rows || []) {
    const code = String(row?.f12 || row?.code || "").trim().padStart(6, "0");
    const market = String(row?.f13 || "").trim() === "1" ? "sh" : "sz";
    const symbol = /^\d{6}$/.test(code) ? `${market}${code}` : "";
    const name = String(row?.f14 || row?.name || "").trim();
    const change = row?.f3 ?? row?.zdf ?? row?.change_percent ?? "";
    if (symbol && name && !stocks.some(stock => stock.code === symbol)) {
      const netInflow = row?.f62 ?? row?.net_inflow ?? row?.zljlr ?? "";
      stocks.push({ code: symbol, name, change_percent: String(change), net_inflow: String(netInflow) });
    }
    if (stocks.length >= Math.max(1, Math.min(Number(limit) || 10, 100))) break;
  }
  return stocks.slice(0, Math.max(1, Math.min(Number(limit) || 10, 100)));
}

async function fetchIndustryConstituents(request) {
  const trace = createTimingTrace("sector_constituents");
  const limit = Math.max(1, Math.min(Number(request.limit) || 10, 100));
  const requestedDirection = String(request.direction || "inflow").toLowerCase();
  const direction = ["inflow","outflow","gain","decline"].includes(requestedDirection)
    ? requestedDirection
    : "inflow";
  trace.mark("fetch_started", { symbol: request.symbol, limit, direction });
  const apiUrl = buildIndustryConstituentUrl(request.symbol, limit, direction);
  trace.mark("url_built", { api_url: apiUrl });
  let tab;
  try {
    tab = await chrome.tabs.create({ url: apiUrl, active: false });
    trace.mark("tab_created", { tab_id: tab?.id ?? null });
    await waitForIndustryTab(tab.id, 30000);
    trace.mark("tab_loaded", { tab_id: tab?.id ?? null });
    const executed = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => ({
        text: document.body?.innerText || "",
        title: document.title || "",
        url: location.href || "",
        ready_state: document.readyState || ""
      })
    });
    trace.mark("page_read", {
      tab_id: tab?.id ?? null,
      body_length: String(executed?.[0]?.result?.text || "").length,
      ready_state: executed?.[0]?.result?.ready_state || ""
    });
    const page = executed?.[0]?.result || {};
    const text = String(page.text || "").trim();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch (_) {
      const start = text.indexOf("(");
      const end = text.lastIndexOf(")");
      if (start < 0 || end <= start) throw new Error("东方财富行业成分股页面未返回有效 JSON");
      payload = JSON.parse(text.slice(start + 1, end));
    }
    trace.mark("json_parsed");
    const stocks = extractIndustryConstituentRows(payload, limit);
    const symbols = stocks.map(stock => stock.code);
    if (!symbols.length) throw new Error("东方财富行业成分股接口没有返回有效股票");
    trace.mark("rows_extracted", { stock_count: stocks.length });
    return {
      symbols,
      stocks,
      apiUrl,
      debug: {
        api_url: apiUrl,
        api_mode: "page_navigation",
        page_url: page.url || apiUrl,
        page_title: page.title || "",
        ready_state: page.ready_state || "",
        body_length: text.length,
        timing: trace.finish({ status: "success" })
      }
    };
  } catch (error) {
    trace.mark("failed", { error: String(error) });
    if (!error || typeof error !== "object") error = new Error(String(error));
    if (!error.debug || typeof error.debug !== "object" || Array.isArray(error.debug)) {
      error.debug = { api_url: apiUrl, api_mode: "page_navigation", page_error: String(error) };
    }
    error.debug.timing = trace.finish({ status: "failed", error: String(error) });
    throw error;
  } finally {
    if (tab?.id != null) try { await chrome.tabs.remove(tab.id); } catch (_) {}
  }
}

function waitForIndustryTab(tabId, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (error, tab) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      error ? reject(error) : resolve(tab);
    };
    const timer = setTimeout(() => finish(new Error("行业页面加载超时")), timeoutMs);
    const listener = (updatedTabId, changeInfo, tab) => {
      if (updatedTabId === tabId && changeInfo.status === "complete") finish(null, tab);
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then(tab => { if (tab.status === "complete") finish(null, tab); }).catch(error => finish(error));
  });
}

async function fetchIndustryPage(request) {
  if (request.fixed_api) {
    try {
      const apiResult = await fetchIndustryApiByEdgePage(request);
      return {
        token: request.token,
        request_id: request.request_id,
        symbol: request.symbol,
        status: "success",
        rows: apiResult.rows,
        source: "eastmoney_edge_fixed_api",
        debug: {
          page_url: FIXED_EASTMONEY_INDUSTRY_API_URL,
          api_url: apiResult.apiUrl,
          api_mode: apiResult.mode || "page_navigation",
          api_response_debug: apiResult.responseDebug || null,
          fixed_api: true
        }
      };
    } catch (error) {
      return {
        token: request.token,
        request_id: request.request_id,
        symbol: request.symbol,
        status: "failed",
        rows: [],
        source: "eastmoney_edge_fixed_api",
        error: `固定行业 API Edge 直测失败：${String(error)}`,
        debug: {
          api_url: FIXED_EASTMONEY_INDUSTRY_API_URL,
          api_mode: "page_navigation",
          fixed_api: true,
          api_edge_page_error: String(error),
          api_response_debug: error?.debug || null
        }
      };
    }
  }
  const url = buildIndustryUrl(request.symbol);

  let tab;
  let pageDebug = { page_url: url };
  let apiTemplateUrl = "";
  try {
    tab = await chrome.tabs.create({ url, active: false });
    await waitForIndustryTab(tab.id, 30000);
    const executed = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const globals = {};
        for (const name of ["HYShiChangBiaoXianJson", "klines", "kline", "KLINE", "chartData"]) if (window[name] != null) globals[name] = window[name];
        const scripts = [...document.scripts].map(script => script.textContent || "").filter(text => /HYShiChangBiaoXianJson|klines|kline/i.test(text)).slice(-5);
        const allResourceUrls = typeof performance !== "undefined"
          ? performance.getEntriesByType("resource").map(entry => entry.name)
          : [];
        const resourceUrls = allResourceUrls.filter(name => /eastmoney|push2|quote/i.test(name)).slice(-40);
        const klineApiUrls = allResourceUrls.filter(name => /push2his\.eastmoney\.com\/api\/qt\/stock\/kline\/get/i.test(name)).slice(-10);
        return {
          globals,
          scripts,
          title: document.title,
          url: location.href,
          ready_state: document.readyState,
          resource_urls: resourceUrls,
          kline_api_urls: klineApiUrls
        };
      }
    });
    const pageInfo = executed?.[0]?.result || {};
    pageDebug = {
      page_url: pageInfo.url || url,
      page_title: pageInfo.title || "",
      ready_state: pageInfo.ready_state || "",
      global_keys: Object.keys(pageInfo.globals || {}),
      script_count: Array.isArray(pageInfo.scripts) ? pageInfo.scripts.length : 0,
      resource_urls: Array.isArray(pageInfo.resource_urls) ? pageInfo.resource_urls : [],
      kline_api_urls: Array.isArray(pageInfo.kline_api_urls) ? pageInfo.kline_api_urls : []
    };
    apiTemplateUrl = findIndustryApiTemplateUrl([...pageDebug.kline_api_urls, ...pageDebug.resource_urls]);
    if (apiTemplateUrl) pageDebug.api_template_url = apiTemplateUrl;
    if (request.dynamic_api) {
      if (!apiTemplateUrl) throw new Error("未从东方财富行业页面发现历史 K 线地址");
      const apiResult = await fetchIndustryApiByEdgePage(request, apiTemplateUrl);
      return {
        token: request.token,
        request_id: request.request_id,
        symbol: request.symbol,
        status: "success",
        rows: apiResult.rows,
        source: "eastmoney_edge_dynamic_api",
        debug: {
          ...pageDebug,
          api_template_url: apiTemplateUrl,
          api_url: apiResult.apiUrl,
          api_mode: apiResult.mode || "page_navigation",
          api_response_debug: apiResult.responseDebug || null,
          dynamic_api: true
        }
      };
    }
    const rows = extractIndustryRows(pageInfo, request);    if (!rows.length) throw new Error("东方财富行业页面未提取到日期序列");
    return { token: request.token, request_id: request.request_id, symbol: request.symbol, status: "success", rows, source: "eastmoney_edge_page", debug: pageDebug };
  } catch (error) {
    const pageError = error;
    let pageApiError = null;
    let edgePageError = null;
    try {
      let apiResult;
      try {
        apiResult = await fetchIndustryApiByEdgePage(request, apiTemplateUrl);
      } catch (errorByEdgePage) {
        edgePageError = errorByEdgePage;
        try {
          apiResult = await fetchIndustryApiInPage(tab?.id, request, apiTemplateUrl);
        } catch (errorInPage) {
          pageApiError = errorInPage;
          apiResult = await fetchIndustryApi(request, apiTemplateUrl);
        }
      }
      return { token: request.token, request_id: request.request_id, symbol: request.symbol, status: "success", rows: apiResult.rows, source: "eastmoney_edge_api", debug: { ...pageDebug, api_template_url: apiTemplateUrl || null, api_url: apiResult.apiUrl, api_mode: apiResult.mode || "background_fetch", api_response_debug: apiResult.responseDebug || null, fallback: true } };
    } catch (apiError) {
      return {
        token: request.token,
        request_id: request.request_id,
        symbol: request.symbol,
        status: "failed",
        rows: [],
        source: "eastmoney_edge_page",
        error: `${String(pageError)}; Edge 行业 K 线回退失败：${pageApiError ? `${String(pageApiError)}；后台 fetch：` : ""}${String(apiError)}`,
        debug: { ...pageDebug, page_error: String(pageError), api_template_url: apiTemplateUrl || null, api_url: buildIndustryApiUrl(request, apiTemplateUrl), api_page_error: pageApiError ? String(pageApiError) : null, api_error: String(apiError), api_edge_page_error: edgePageError ? String(edgePageError) : null, api_response_debug: apiError?.debug || pageApiError?.debug || edgePageError?.debug || null }
      };
    }
  } finally {
    if (tab?.id != null) try { await chrome.tabs.remove(tab.id); } catch (_) {}
  }
}

async function postIndustryData(watchlist, payload) {
  const response = await fetchWithTimeout(`${BRIDGE_URL}/api/industry-data`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: watchlist.token, ...payload }) });
  if (!response.ok) throw new Error(`行业数据回传失败（HTTP ${response.status}）`);
}

async function postPeerData(watchlist, payload) {
  const response = await fetchWithTimeout(`${BRIDGE_URL}/api/peer-data`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token: watchlist.token, ...payload })
  });
  if (!response.ok) throw new Error(`同行股票数据回传失败（HTTP ${response.status}）`);
}

async function syncIndustryRequests(watchlist) {
  const response = await fetchWithTimeout(`${BRIDGE_URL}/api/industry-requests?limit=5`, { headers: { "X-StockTray-Token": watchlist.token }, cache: "no-store" });
  if (!response.ok) throw new Error(`行业请求领取失败（HTTP ${response.status}）`);
  const payload = await response.json();
  const requests = Array.isArray(payload.requests) ? payload.requests.slice(0, 5) : [];
  let completed = 0;
  for (const request of requests) {
    await postIndustryData(watchlist, await fetchIndustryPage({ ...request, token: watchlist.token }));
    completed += 1;
  }
  return completed;
}

async function syncPeerRequests(watchlist) {
  const response = await fetchWithTimeout(`${BRIDGE_URL}/api/peer-requests?limit=5`, {
    headers: { "X-StockTray-Token": watchlist.token }, cache: "no-store"
  });
  if (!response.ok) throw new Error(`同行股票请求领取失败（HTTP ${response.status}）`);
  const payload = await response.json();
  const requests = Array.isArray(payload.requests) ? payload.requests.slice(0, 5) : [];
  let completed = 0;
  const errors = [];
  for (const request of requests) {
    const claimedAt = performance.now();
    try {
      const result = await fetchIndustryConstituents(request);
      await postPeerData(watchlist, {
        request_id: request.request_id,
        symbol: request.symbol,
        status: "success",
        symbols: result.symbols,
        stocks: result.stocks,
        source: "eastmoney_edge",
        debug: {
          ...(result.debug || {}),
          api_url: result.apiUrl,
          limit: request.limit,
          direction: request.direction || "inflow",
          queue_to_result_before_post_ms: Math.round((performance.now() - claimedAt) * 10) / 10
        }
      });
    } catch (error) {
      const message = String(error);
      errors.push({ kind: "peer_discovery", symbol: request.symbol, message });
      await postPeerData(watchlist, {
        request_id: request.request_id,
        symbol: request.symbol,
        status: "failed",
        symbols: [],
        stocks: [],
        source: "eastmoney_edge",
        error: message,
        debug: {
          ...(error?.debug || {}),
          queue_to_result_before_post_ms: Math.round((performance.now() - claimedAt) * 10) / 10
        }
      });
    }
    completed += 1;
  }
  return { completed, errors };
}

function buildEastmoneyEventPageUrl(kind, symbol) {
  const code = String(symbol || "").replace(/^(sh|sz|bj)/i, "").padStart(6, "0");
  if (!/^\d{6}$/.test(code)) throw new Error("无效股票代码");
  if (kind === "shareholders") return `https://data.eastmoney.com/gdhs/detail/${code}.html`;
  if (kind === "corporate_actions") return `https://data.eastmoney.com/yjfp/detail/${code}.html`;
  throw new Error("无效东方财富事件类型");
}

function buildEastmoneyEventApiUrl(kind, symbol, templateUrl = "") {
  const code = String(symbol || "").replace(/^(sh|sz|bj)/i, "").padStart(6, "0");
  const reportName = kind === "shareholders" ? "RPT_HOLDERNUM_DET" : "RPT_SHAREBONUS_DET";
  const defaultColumns = kind === "shareholders"
    ? "SECURITY_CODE,SECURITY_NAME_ABBR,CHANGE_SHARES,CHANGE_REASON,END_DATE,INTERVAL_CHRATE,AVG_MARKET_CAP,AVG_HOLD_NUM,TOTAL_MARKET_CAP,TOTAL_A_SHARES,HOLD_NOTICE_DATE,HOLDER_NUM,PRE_HOLDER_NUM,HOLDER_NUM_CHANGE,HOLDER_NUM_RATIO,PRE_END_DATE"
    : "ALL";
  let url;
  try { url = new URL(templateUrl || EASTMONEY_EVENT_API_URL); } catch (_) { url = new URL(EASTMONEY_EVENT_API_URL); }
  url.search = "";
  const params = new URLSearchParams({
    sortColumns: kind === "shareholders" ? "END_DATE" : "REPORT_DATE",
    sortTypes: "-1",
    pageSize: "500",
    pageNumber: "1",
    reportName,
    columns: defaultColumns,
    quoteColumns: "",
    filter: `(SECURITY_CODE="${code}")`,
    source: "WEB",
    client: "WEB"
  });
  url.search = params.toString();
  return url.toString();
}

function findEastmoneyEventApiTemplate(resourceUrls, kind) {
  const reportName = kind === "shareholders" ? "RPT_HOLDERNUM_DET" : "RPT_SHAREBONUS_DET";
  if (!Array.isArray(resourceUrls)) return "";
  for (const candidate of [...resourceUrls].reverse()) {
    try {
      const url = new URL(String(candidate));
      if (url.hostname.toLowerCase() === "datacenter-web.eastmoney.com" && url.searchParams.get("reportName") === reportName) return url.toString();
    } catch (_) {}
  }
  return "";
}

function extractEastmoneyEventRows(payload) {
  const result = payload && typeof payload === "object" ? payload.result : null;
  let rows = result && result.data != null ? result.data : (payload && typeof payload === "object" ? payload.data : []);
  if (rows && !Array.isArray(rows) && typeof rows === "object") rows = Object.values(rows);
  return rows.filter(row => row && typeof row === "object");
}

async function fetchEastmoneyEventPages(apiUrl) {
  const rows = [];
  let pages = 1;
  for (let pageNumber = 1; pageNumber <= pages && pageNumber <= 20; pageNumber += 1) {
    const url = new URL(apiUrl);
    url.searchParams.set("pageNumber", String(pageNumber));
    const payload = await fetchEastmoneyJson(url.toString());
    const result = payload && typeof payload === "object" ? payload.result : null;
    pages = Math.max(1, Math.min(Number(result?.pages) || 1, 20));
    rows.push(...extractEastmoneyEventRows(payload));
    if (!Array.isArray(result?.data) || !result.data.length) break;
  }
  if (!rows.length) {
    const error = new Error("东方财富事件接口没有返回有效数据");
    error.debug = { api_url: apiUrl, page_count: pages, row_count: 0 };
    throw error;
  }
  return { rows, pages };
}

async function fetchEastmoneyEvent(request) {
  const pageUrl = buildEastmoneyEventPageUrl(request.kind, request.symbol);
  const pageDebug = { page_url: pageUrl, resource_urls: [], page_title: "", ready_state: "" };
  const directApiUrl = buildEastmoneyEventApiUrl(request.kind, request.symbol);
  try {
    const direct = await fetchEastmoneyEventPages(directApiUrl);
    return {
      rows: direct.rows,
      apiUrl: directApiUrl,
      debug: {
        ...pageDebug,
        api_url: directApiUrl,
        api_template_url: null,
        api_mode: "edge_extension_direct",
        page_count: direct.pages,
        row_count: direct.rows.length
      }
    };
  } catch (error) {
    pageDebug.direct_api_error = String(error);
    pageDebug.direct_api_debug = error?.debug || null;
  }

  let tab;
  try {
    tab = await chrome.tabs.create({ url: pageUrl, active: false });
    await waitForIndustryTab(tab.id, 30000);
    const executed = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => ({
        title: document.title,
        url: location.href,
        ready_state: document.readyState,
        resource_urls: typeof performance !== "undefined"
          ? performance.getEntriesByType("resource").map(entry => entry.name).filter(name => /eastmoney|datacenter/i.test(name)).slice(-100)
          : []
      })
    });
    const page = executed?.[0]?.result || {};
    pageDebug.page_url = page.url || pageUrl;
    pageDebug.page_title = page.title || "";
    pageDebug.ready_state = page.ready_state || "";
    pageDebug.resource_urls = Array.isArray(page.resource_urls) ? page.resource_urls : [];
  } catch (error) {
    pageDebug.page_error = String(error);
  } finally {
    if (tab?.id != null) try { await chrome.tabs.remove(tab.id); } catch (_) {}
  }

  const templateUrl = findEastmoneyEventApiTemplate(pageDebug.resource_urls, request.kind);
  const apiUrl = buildEastmoneyEventApiUrl(request.kind, request.symbol, templateUrl);
  try {
    const fallback = await fetchEastmoneyEventPages(apiUrl);
    return {
      rows: fallback.rows,
      apiUrl,
      debug: {
        ...pageDebug,
        api_url: apiUrl,
        api_template_url: templateUrl || null,
        api_mode: "edge_page_template",
        page_count: fallback.pages,
        row_count: fallback.rows.length
      }
    };
  } catch (error) {
    error.debug = {
      ...pageDebug,
      ...(error?.debug || {}),
      api_url: apiUrl,
      api_template_url: templateUrl || null
    };
    throw error;
  }
}

async function postEventData(watchlist, payload) {
  const response = await fetchWithTimeout(`${BRIDGE_URL}/api/event-data`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token: watchlist.token, ...payload })
  });
  if (!response.ok) throw new Error(`东方财富事件数据回传失败（HTTP ${response.status}）`);
}

async function syncEventRequests(watchlist) {
  const response = await fetchWithTimeout(`${BRIDGE_URL}/api/event-requests?limit=5`, {
    headers: { "X-StockTray-Token": watchlist.token }, cache: "no-store"
  });
  if (!response.ok) throw new Error(`东方财富事件请求领取失败（HTTP ${response.status}）`);
  const payload = await response.json();
  const requests = Array.isArray(payload.requests) ? payload.requests.slice(0, 5) : [];
  let completed = 0;
  for (const request of requests) {
    try {
      const result = await fetchEastmoneyEvent(request);
      await postEventData(watchlist, {
        request_id: request.request_id,
        kind: request.kind,
        symbol: request.symbol,
        status: "success",
        rows: result.rows,
        source: request.kind === "shareholders" ? "eastmoney_edge_gdhs" : "eastmoney_edge_yjfp",
        debug: result.debug
      });
    } catch (error) {
      await postEventData(watchlist, {
        request_id: request.request_id,
        kind: request.kind,
        symbol: request.symbol,
        status: "failed",
        rows: [],
        source: "eastmoney_edge",
        error: String(error),
        debug: error?.debug || null
      });
    }
    completed += 1;
  }
  return completed;
}

async function waitForEventWake(timeoutMs = 25000) {
  const watchlist = await getWatchlist();
  const url = `${BRIDGE_URL}/api/event-wakeup?since=${encodeURIComponent(eventWakeGeneration)}&wait=25`;
  const response = await fetchWithTimeout(url, {
    timeoutMs,
    headers: { "X-StockTray-Token": watchlist.token },
    cache: "no-store"
  });
  if (!response.ok) throw new Error(`东方财富事件唤醒请求失败（HTTP ${response.status}）`);
  const payload = await response.json();
  eventWakeGeneration = Math.max(eventWakeGeneration, Number(payload?.generation) || 0);
  return payload;
}

function syncEventNow() {
  if (syncInFlight) return syncInFlight;
  if (eventSyncInFlight) return eventSyncInFlight;
  eventSyncInFlight = (async () => {
    const watchlist = await getWatchlist();
    await syncEventRequests(watchlist);
  })().finally(() => { eventSyncInFlight = null; });
  return eventSyncInFlight;
}

async function syncQueuePass(watchlist) {
  const errors = [];
  const peer = await syncPeerRequests(watchlist).catch(error => {
    errors.push(serializeRequestError("peer_discovery", error));
    return { completed: 0, errors: [] };
  });
  errors.push(...peer.errors);
  const industry = await syncIndustryRequests(watchlist).catch(error => {
    errors.push(serializeRequestError("industry", error));
    return 0;
  });
  const events = await syncEventRequests(watchlist).catch(error => {
    errors.push(serializeRequestError("eastmoney_event", error));
    return 0;
  });
  return { completed: peer.completed + industry + events, errors };
}

function syncQueueNow() {
  if (queueSyncInFlight) return queueSyncInFlight;
  queueSyncInFlight = (async () => {
    const watchlist = await getWatchlist();
    let completed = 0;
    const errors = [];
    let passes = 0;
    while (passes < 5) {
      passes += 1;
      const result = await syncQueuePass(watchlist);
      completed += result.completed;
      errors.push(...result.errors);
      if (result.completed === 0) break;
    }
    return { completed, errors };
  })().finally(() => { queueSyncInFlight = null; });
  return queueSyncInFlight;
}

function startEventWakeListener() {
  if (eventWakeInFlight) return eventWakeInFlight;
  eventWakeInFlight = (async () => {
    while (true) {
      try {
        const signal = await waitForEventWake();

        // V1.1.7:
        // watchlist_changed means a custom stock was just added.
        // The old 1.1.3 code only called syncQueueNow(), which does NOT call
        // syncStockData(), so the new stock could wait until the 30-second alarm.
        if (
          signal?.watchlist_changed ||
          signal?.force_refresh ||
          signal?.periodic_refresh_due ||
          signal?.full_refresh
        ) {
          // V1.1.7：自定义个股变化或 10 秒周期刷新，都执行完整同步。
          // 完整同步包含股票 + 板块资金，保证板块源数据本身约 10 秒更新一次。
          await syncNow(!!signal?.watchlist_changed || !!signal?.force_refresh);
        } else if (signal?.woken) {
          await syncQueueNow();
        }
      } catch (_) {
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
  })();
  return eventWakeInFlight;
}
function chinaTradingPhase() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone:"Asia/Shanghai",
    weekday:"short",
    hour:"2-digit",
    minute:"2-digit",
    hourCycle:"h23"
  }).formatToParts(new Date());

  const get=type=>parts.find(x=>x.type===type)?.value || "";
  const weekday=get("weekday");
  const minutes=Number(get("hour"))*60+Number(get("minute"));

  if (weekday === "Sat" || weekday === "Sun") return {key:"closed",label:"已收盘"};
  if (minutes >= 555 && minutes < 570) return {key:"auction",label:"集合竞价"};
  if ((minutes >= 570 && minutes <= 690) || (minutes >= 780 && minutes <= 900)) {
    return {key:"trading",label:"交易中"};
  }
  if (minutes > 690 && minutes < 780) return {key:"lunch",label:"午休"};
  return {key:"closed",label:"已收盘"};
}

function refreshIntervalsMs() {
  const phase=chinaTradingPhase();
  if (phase.key === "trading" || phase.key === "auction") {
    return {phase,stock:5000,market:10000,sector:10000};
  }
  if (phase.key === "lunch") {
    return {phase,stock:30000,market:60000,sector:60000};
  }
  return {phase,stock:120000,market:300000,sector:300000};
}

async function fetchMarketIndicesData() {
  const fields="f12,f14,f2,f3,f4,f5,f6,f15,f16,f17,f18,f104,f105,f106";
  const params=new URLSearchParams({
    fltt:"2",
    invt:"2",
    secids:"1.000001,0.399006",
    fields,
    ut:"fa5fd1943c7b386f172d6893dbbd1d0c"
  });
  const payload=await fetchEastmoneyJson(`${EASTMONEY_MARKET_URL}?${params.toString()}`);
  const raw=payload?.data?.diff;
  const rows=Array.isArray(raw)?raw:(raw&&typeof raw==="object"?Object.values(raw):[]);
  if(rows.length<2)throw new Error("大盘指数接口返回为空");

  const num=v=>Number.isFinite(Number(v))?Number(v):null;
  const norm=(r,code,name)=>({
    code:String(r?.f12||code),
    name:String(r?.f14||name),
    index:num(r?.f2),
    pct:num(r?.f3)??0,
    change:num(r?.f4),
    volume:num(r?.f5),
    turnover:num(r?.f6),
    high:num(r?.f15),
    low:num(r?.f16),
    open:num(r?.f17),
    preClose:num(r?.f18),
    riseCount:num(r?.f104),
    fallCount:num(r?.f105),
    flatCount:num(r?.f106)
  });
  return {
    sh:norm(rows.find(r=>String(r?.f12)==="000001")||rows[0],"000001","上证指数"),
    cy:norm(rows.find(r=>String(r?.f12)==="399006")||rows[1],"399006","创业板指")
  };
}

async function performSync(force = false) {
  const watchlist = await getWatchlist();
  const stocks = Array.isArray(watchlist.stocks) ? watchlist.stocks : [];
  const now=Date.now();
  const intervals=refreshIntervalsMs();

  const stockDue=force || !lastStockSyncAt || now-lastStockSyncAt>=intervals.stock;
  const marketDue=force || !lastMarketSyncAt || now-lastMarketSyncAt>=intervals.market;
  const sectorDue=force || !lastSectorSyncAt || now-lastSectorSyncAt>=intervals.sector;

  const errors=[];
  let stockResult={quotes:[],intraday:[],errors:[]};
  let requestedMetaResult={value:null,error:null};
  let marketResult=null;

  const jobs=[];
  if(stockDue){
    jobs.push(syncStockData(stocks).then(value=>{
      stockResult=value;
      lastStockSyncAt=Date.now();
    }));
    jobs.push(
      fetchRequestedStockMeta(watchlist)
        .then(value=>{requestedMetaResult={value,error:null};})
        .catch(error=>{requestedMetaResult={value:null,error};})
    );
  }
  if(marketDue){
    jobs.push(
      fetchMarketIndicesData()
        .then(value=>{
          marketResult=value;
          lastMarketSyncAt=Date.now();
        })
        .catch(error=>errors.push(serializeRequestError("market_index",error)))
    );
  }

  await Promise.all(jobs);

  if(requestedMetaResult.error){
    errors.push({
      kind:"custom_stock_meta",
      key:watchlist.requested_code || "",
      message:String(requestedMetaResult.error)
    });
  }
  errors.push(...stockResult.errors);

  if(stockDue || marketDue || requestedMetaResult.value){
    await postBrowserData(watchlist,{
      quotes:stockResult.quotes,
      intraday:stockResult.intraday,
      requested_stock_meta:requestedMetaResult.value,
      market:marketResult,
      scheduler:{
        phase:intervals.phase,
        stock_interval_ms:intervals.stock,
        market_interval_ms:intervals.market,
        sector_interval_ms:intervals.sector
      },
      errors
    });
  }

  let sectorUpdated=false;
  if(sectorDue){
    const sectorResult=await syncSectorData();
    lastSectorSyncAt=Date.now();
    errors.push(...sectorResult.errors);

    const sector={};
    for(const column of ["gainers","losers","fund_gainers","fund_losers"]){
      if(sectorResult[column]!==null)sector[column]=sectorResult[column];
    }
    if(Object.keys(sector).length)sector.updated_at=new Date().toISOString();

    await postBrowserData(watchlist,{
      sector:Object.keys(sector).length?sector:null,
      scheduler:{
        phase:intervals.phase,
        stock_interval_ms:intervals.stock,
        market_interval_ms:intervals.market,
        sector_interval_ms:intervals.sector
      },
      errors
    });
    sectorUpdated=Object.keys(sector).length>0;
  }

  const queueResult=await syncQueueNow();
  errors.push(...queueResult.errors);
  await chrome.storage.local.set({
    lastSync:new Date().toISOString(),
    lastError:errors.length?errors:null,
    schedulerPhase:intervals.phase
  });

  return {
    quotes:stockResult.quotes.length,
    intraday:stockResult.intraday.length,
    market:!!marketResult,
    sector:sectorUpdated,
    phase:intervals.phase.key,
    errors:errors.length
  };
}

function syncNow(force = false) {
  if (syncInFlight) return syncInFlight;
  syncInFlight = performSync(force).finally(() => { syncInFlight = null; });
  return syncInFlight;
}

function scheduleAlarm() {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: POLL_MINUTES });
}

chrome.runtime.onInstalled.addListener(() => { scheduleAlarm(); startEventWakeListener(); syncNow().catch(() => {}); });
chrome.runtime.onStartup.addListener(() => { scheduleAlarm(); startEventWakeListener(); syncNow().catch(() => {}); });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) { startEventWakeListener(); syncNow().catch(() => {}); }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "syncNow") {
    syncNow().then(sendResponse).catch(error => sendResponse({ error: String(error) }));
    return true;
  }
  return false;
});

startEventWakeListener();
