# StockTray Edge 腾讯行情扩展

1. 在 Edge 地址栏打开 `edge://extensions/`。
2. 打开“开发人员模式”。
3. 点击“加载解压缩的扩展”，选择本目录。
4. 先启动 StockTray，再点击扩展弹窗中的“立即获取一次”。

扩展通过腾讯的 `qt.gtimg.cn` 实时行情接口和
`ifzq.gtimg.cn/appstock/app/minute/query` 分时接口获取个股行情，
再使用东方财富 `data.eastmoney.com/dataapi/bkzj/getbkzj?key=f62&code=m%3A90%2Bs%3A4` 读取行业板块资金数据，取返回 JSON 的前十和最后十条，
在扩展内按 `f3` 排序得到涨幅前十和跌幅前十，再按 `f62` 排序得到资金净流入前五和净流出前五，
再通过本机 `127.0.0.1:17890` 回传给 StockTray。浏览器扩展运行期间必须保持 Edge 打开。

点击板块细胞后，扩展会使用该板块代码请求东方财富 `push2.eastmoney.com/api/qt/clist/get`：净流入使用 `fid=f62&po=1&fs=b:BKxxxx`，净流出使用 `fid=f62&po=0&fs=b:BKxxxx`，每次只取当前板块排名前十。


行业指数补取：当 StockTray 提交 BK 行业代码的请求后，扩展会从本地桥接队列领取最多 5 个任务，使用 Edge 打开不可见的 https://quote.eastmoney.com/bk/90.BKxxxx.html#fullScreenChart 页面，读取页面中的历史序列并按日期过滤，再回传给 StockTray。StockTray 和 Edge 必须持续运行；临时页面在每次任务完成或失败后都会关闭。


## V1.1.4 自定义个股即时刷新修复

这个版本专门配合 StockCellDesktop V1.59：

- 原 V1.1.3 每 0.5 分钟（约 30 秒）才执行一次完整 `syncNow()`。
- 原 `/api/event-wakeup` 被唤醒后只执行 `syncQueueNow()`，不会执行 `syncStockData()`。
- 所以桌面端新增自定义股票后，即使 17890 watchlist 已更新，也可能在桌面端超时前拿不到行情。

V1.1.4 改为：
- 收到 `watchlist_changed / force_refresh` 立即执行 `syncNow()`；
- 立即重新读取 `/api/watchlist`；
- 立即通过腾讯 `qt.gtimg.cn` 获取新股票实时行情；
- 对最新请求股票额外请求东方财富 `stock/get` 获取 `f127` 所属板块；
- browser-data 回传扩展版本号，方便桌面端诊断。


## V1.1.6：板块资金 10 秒刷新

配合 StockCellDesktop V1.61：
- `/api/event-wakeup` 每当最近 browser-data 已超过约 9.5 秒，会返回 `periodic_refresh_due=true`；
- 扩展收到后立即执行 `syncNow()`；
- `syncNow()` 会重新获取股票行情与东方财富板块资金；
- 因此板块资金源不再只依赖 Chrome 约 30 秒 alarm。

Chrome alarm 仍保留作为后台保险，但主要实时刷新由 17890 event-wakeup 驱动。


## V1.1.6 分时域名修正

腾讯分时接口改为：

`https://ifzq.gtimg.cn/appstock/app/minute/query?code=sz000582`

旧的 `web.ifzq.gtimg.cn` 不再使用。

manifest 的 host permission 也同步改为：

`https://ifzq.gtimg.cn/*`
